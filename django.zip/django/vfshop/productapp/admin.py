from itertools import product
from django.contrib import admin
from .productmodel.product import Product

# Register your models here.
admin.site.register(Product)
