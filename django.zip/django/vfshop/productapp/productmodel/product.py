from datetime import date
from sqlite3 import Date
from django.db import models

# Create your models here.
class Product(models.Model):
    name = models.CharField(max_length=100)
    weight = models.IntegerField(default=0)
    price = models.IntegerField(default=0)
    created_at = models.DateField(Date)
    updated_at = models.DateField(Date)

