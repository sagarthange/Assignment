from django.contrib import admin
from django.urls import path
from user import views as v 

urlpatterns = [
    path('',v.home),
    path('admin/', admin.site.urls),
    path('user',v.user),
]
