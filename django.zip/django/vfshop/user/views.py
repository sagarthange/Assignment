from django.shortcuts import render
from .postmodel.post import Post,PostForm
from user.postmodel import post 

# Create your views here.
def home(request):
    return render(request,"home.html")

def user(request):
    if request.method=="POST":
        f=PostForm(request.POST)
        f.save()
        el=Post.objects.all()
        d={'form':PostForm,'el':el}
        return render(request,'user.html',d)
    else:
        el=Post.objects.all()
        return render(request,"user.html",{'form':PostForm,'el':el})

