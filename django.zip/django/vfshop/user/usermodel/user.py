from django.db import models

# Create your models here.
class User(models.Model):
    first_name = models.CharField(max_length=20)
    last_name = models.CharField(max_length=20)
    email = models.EmailField(max_length=15)
    password = models.CharField(max_length=15)
    username = models.CharField(max_length=20)

