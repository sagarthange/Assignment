from datetime import date
from sqlite3 import Date
from django.db import models
from user.usermodel.user import User
from django import forms
from dataclasses import fields
from datetime import date
from sqlite3 import Date

# Create your models here.
class Post(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    text = models.CharField(max_length=300)
    created_at = models.DateField(Date)
    updated_at = models.DateField(Date)

    class Meta:
        db_table = "Post"

class PostForm(forms.ModelForm):
    class Meta:
        model=Post
        fields='__all__'


